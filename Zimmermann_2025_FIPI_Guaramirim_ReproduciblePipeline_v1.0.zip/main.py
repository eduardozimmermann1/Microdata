"""
main_eth.py

Fine-Grained Poverty and Insecurity Index (FIPI)
ETH-style pipeline for Guaramirim (CadÚnico, Nov/2025).

This script:
- builds household-level vulnerability variables;
- aggregates to neighborhoods;
- constructs multiple FIPI variants;
- computes uncertainty (standard errors);
- performs robustness & sensitivity analysis;
- runs spatial autocorrelation (Moran’s I, LISA);
- performs external validation with Bolsa Família and school supply;
- exports tables, figures and spatial layers for paper-quality output.
"""

import os
import unicodedata
from typing import Tuple

import numpy as np
import pandas as pd
import geopandas as gpd
import matplotlib.pyplot as plt

from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA

from esda.moran import Moran, Moran_Local
from libpysal.weights import Queen


# ============================================================
# 1. PATH CONFIGURATION
# ============================================================

BASE_DIR = r"C:\Users\eduar\Desktop\Arquivos Eduardo\CADUNICO Guaramirim"

INPUT_CAD       = os.path.join(BASE_DIR, "Dados Cad 04-11-25.csv")
BAIRROS_SHP     = os.path.join(BASE_DIR, "bairrosGuaramirim.shp")
MUNICIPIO_SHP   = os.path.join(BASE_DIR, "limitesGuaramirim.shp")

# external data
INPUT_SCHOOLS   = os.path.join(BASE_DIR, "ESCOLAS_GUARAMIRIM.csv")

# CSV outputs
OUTPUT_AGG              = os.path.join(BASE_DIR, "cadunico_guaramirim_agg_bairros_en.csv")
AGG_WITH_PCA_OUTPUT     = os.path.join(BASE_DIR, "agg_with_pca.csv")
UNCERTAINTY_OUTPUT      = os.path.join(BASE_DIR, "uncertainty_measures.csv")
MISSING_OUTPUT          = os.path.join(BASE_DIR, "missing_report.csv")
OUTLIERS_OUTPUT         = os.path.join(BASE_DIR, "outliers_report.csv")
SENSITIVITY_OUTPUT      = os.path.join(BASE_DIR, "fipi_sensitivity_analysis.csv")
SPATIAL_LISA_OUTPUT     = os.path.join(BASE_DIR, "spatial_with_lisa.geojson")
SPATIAL_STATS_SUMMARY   = os.path.join(BASE_DIR, "spatial_stats_summary.csv")
PBF_COVERAGE_OUTPUT     = os.path.join(BASE_DIR, "pbf_coverage_by_bairro.csv")
SCHOOLS_COVERAGE_OUTPUT = os.path.join(BASE_DIR, "schools_coverage_by_bairro.csv")

# Figures (usadas no LaTeX)
MAP_OUTPUT              = os.path.join(BASE_DIR, "guaramirim_fipi_bairros.png")
TABLE_OUTPUT            = os.path.join(BASE_DIR, "guaramirim_fipi_table.png")
CORR_FIG_OUTPUT         = os.path.join(BASE_DIR, "correlation_matrix.png")
LISA_SCATTER_OUTPUT     = os.path.join(BASE_DIR, "lisa_moran_scatterplot.png")
LISA_CLUSTERS_OUTPUT    = os.path.join(BASE_DIR, "lisa_clusters_map.png")
LISA_SIGNIFICANT_OUTPUT = os.path.join(BASE_DIR, "lisa_significant_map.png")


# ============================================================
# 2. HELPER FUNCTIONS
# ============================================================

def normalize_bairro(name: str) -> str:
    """Normalize neighborhood/locality names: remove accents, uppercase, trim."""
    if not isinstance(name, str):
        return ""
    s = name.strip().upper()
    s = unicodedata.normalize("NFKD", s)
    s = "".join(ch for ch in s if not unicodedata.combining(ch))
    s = " ".join(s.split())
    return s


def load_cadunico(path: str) -> pd.DataFrame:
    """Load the raw CadÚnico dataset from CSV (CECAD-style layout)."""
    print("Loading CadÚnico raw data...")
    df = pd.read_csv(path, sep=";", encoding="latin1", low_memory=False)

    # Strip spaces in column names (e.g., ' d.vlr_renda_total_fam')
    df.columns = df.columns.str.strip()

    print("Total records:", len(df))
    print("Available columns (first 20):", df.columns.tolist()[:20])
    return df


# ============================================================
# 3. VARIABLE CONSTRUCTION (HOUSEHOLD LEVEL)
# ============================================================

def prepare_vulnerability_variables(df: pd.DataFrame) -> pd.DataFrame:
    """
    Build household-level vulnerability variables.

    Dimensions:
    1) Extreme poverty (income_pc <= 218)
    2) High crowding (persons per bedroom >= 3)
    3) High food burden (food_exp / income_total >= 0.4)
    4) Compound housing/sanitation vulnerability index (IVD, 0–1):
       - high medication burden >= 20% income
       - no piped water
       - no bathroom
       - precarious waste disposal (codes 4–6)
       - precarious lighting (codes 4–6)
       - indigenous family
    """

    print("\nPreparing vulnerability variables...")

    df = df.copy()

    # Map raw columns to simpler names
    colmap = {
        "d.nom_localidade_fam":         "bairro_raw",
        "d.vlr_renda_total_fam":        "income_total",
        "d.marc_pbf":                   "is_pbf",
        "d.qtd_comodos_dormitorio_fam": "n_bedrooms",
        "d.cod_agua_canalizada_fam":    "water_code",
        "d.cod_banheiro_domic_fam":     "bathroom_code",
        "d.cod_destino_lixo_domic_fam": "waste_code",
        "d.cod_iluminacao_domic_fam":   "lighting_code",
        "d.cod_familia_indigena_fam":   "indigenous_code",
        "d.qtd_pessoas_domic_fam":      "n_people",
        "d.qtd_familias_domic_fam":     "n_families_sharing",
        "d.val_desp_energia_fam":       "exp_energy",
        "d.val_desp_agua_esgoto_fam":   "exp_water_sewage",
        "d.val_desp_gas_fam":           "exp_gas",
        "d.val_desp_alimentacao_fam":   "exp_food",
        "d.val_desp_transpor_fam":      "exp_transport",
        "d.val_desp_aluguel_fam":       "exp_rent",
        "d.val_desp_medicamentos_fam":  "exp_meds",
    }

    missing_in_df = [c for c in colmap.keys() if c not in df.columns]
    if missing_in_df:
        print("\n[WARNING] The following expected columns are missing in the CSV:")
        for c in missing_in_df:
            print("   -", c)
        print("They will be created as NaN and excluded from indicators where relevant.")

    for raw, new in colmap.items():
        if raw in df.columns:
            df = df.rename(columns={raw: new})
        else:
            df[new] = np.nan

    # Numeric conversions
    num_cols = [
        "income_total", "n_bedrooms", "n_people", "n_families_sharing",
        "exp_energy", "exp_water_sewage", "exp_gas",
        "exp_food", "exp_transport", "exp_rent", "exp_meds"
    ]
    for c in num_cols:
        df[c] = pd.to_numeric(df[c], errors="coerce")
        df[c] = df[c].clip(lower=0)

    # Coded variables
    code_cols = ["water_code", "bathroom_code", "waste_code",
                 "lighting_code", "indigenous_code", "is_pbf"]
    for c in code_cols:
        df[c] = pd.to_numeric(df[c], errors="coerce")

    # Bolsa Família flag (0/1)
    if "is_pbf" in df.columns:
        df["is_pbf"] = pd.to_numeric(df["is_pbf"], errors="coerce").fillna(0)
        df["is_pbf"] = (df["is_pbf"] > 0).astype(int)
    else:
        df["is_pbf"] = 0

    # --------------------------------------------------------
    # Income per capita
    # --------------------------------------------------------
    df["income_pc"] = np.where(
        df["n_people"] > 0,
        df["income_total"] / df["n_people"],
        np.nan
    )

    EXTREME_POVERTY_LINE = 218.0
    df["is_extreme_poor"] = (
        df["income_pc"].notna() &
        (df["income_pc"] <= EXTREME_POVERTY_LINE)
    )

    # --------------------------------------------------------
    # Crowding: people per bedroom
    # --------------------------------------------------------
    df["crowding"] = np.where(
        (df["n_people"] > 0) & (df["n_bedrooms"] > 0),
        df["n_people"] / df["n_bedrooms"],
        np.nan
    )
    df["is_high_crowding"] = (
        df["crowding"].notna() &
        (df["crowding"] >= 3.0)
    )

    # --------------------------------------------------------
    # Food burden: share of income spent on food
    # --------------------------------------------------------
    df["food_share"] = np.where(
        df["income_total"] > 0,
        df["exp_food"] / df["income_total"],
        np.nan
    )
    df["is_high_food_burden"] = (
        df["food_share"].notna() &
        (df["food_share"] >= 0.40)
    )

    # --------------------------------------------------------
    # Compound housing/sanitation vulnerability (IVD)
    # --------------------------------------------------------
    df["med_share"] = np.where(
        df["income_total"] > 0,
        df["exp_meds"] / df["income_total"],
        np.nan
    )
    high_med    = df["med_share"].notna() & (df["med_share"] >= 0.20)
    no_water    = (df["water_code"] == 2)
    no_bathroom = (df["bathroom_code"] == 2)
    bad_waste   = df["waste_code"].isin([4, 5, 6])
    bad_light   = df["lighting_code"].isin([4, 5, 6])
    indigenous  = (df["indigenous_code"] == 1)

    components = [
        high_med.fillna(False).astype(int),
        no_water.fillna(False).astype(int),
        no_bathroom.fillna(False).astype(int),
        bad_waste.fillna(False).astype(int),
        bad_light.fillna(False).astype(int),
        indigenous.fillna(False).astype(int),
    ]

    df["ivd_sum"] = sum(components)
    df["ivd_mean"] = df["ivd_sum"] / 6.0   # in [0,1]

    # --------------------------------------------------------
    # Normalize neighborhood names
    # --------------------------------------------------------
    df["bairro_norm"] = df["bairro_raw"].apply(normalize_bairro)

    corrections = {
        "BEIRO RIO": "BEIRA RIO",
        "CORTEICEIRA": "CORTICEIRA",
        "CORTICIERA": "CORTICEIRA",
        "COSTICEIRA": "CORTICEIRA",
        "CAIX DAGUA": "CAIXA D AGUA",
        "CAIXA DAGUA": "CAIXA D AGUA",
        "CAIXA DA AGUA": "CAIXA D AGUA",
        "BRUDHERTAL": "BRUDERTHAL I",
        "BRUDERTHAL": "BRUDERTHAL I",
        "NOVA ESPERANA": "NOVA ESPERANCA",
        "JACU ACU": "JACU-ACU",
    }
    df["bairro_norm"] = df["bairro_norm"].replace(corrections)

    # Group some localities into OUTROS (no polygons)
    bairros_outros = {"PONTA COMPRIDA", "PUTANGA", "SERENATA", "TIBAGI"}
    df["bairro_norm"] = df["bairro_norm"].replace({b: "OUTROS" for b in bairros_outros})

    return df


# ============================================================
# 4. AGGREGATION AND FIPI VARIANTS
# ============================================================

def aggregate_by_bairro(df: pd.DataFrame) -> pd.DataFrame:
    """Aggregate vulnerability indicators by neighborhood and compute base FIPI."""

    print("\nAggregating by neighborhood...")

    df_valid = df[df["bairro_norm"] != ""].copy()

    grouped = df_valid.groupby("bairro_norm").agg(
        n_families=("bairro_norm", "count"),
        n_people_total=("n_people", "sum"),
        mean_income_pc=("income_pc", "mean"),
        share_extreme_poverty=("is_extreme_poor", "mean"),
        share_high_crowding=("is_high_crowding", "mean"),
        share_high_food_burden=("is_high_food_burden", "mean"),
        ivd_mean=("ivd_mean", "mean"),
        # Bolsa Família:
        n_pbf_families=("is_pbf", "sum"),
        share_pbf_families=("is_pbf", "mean"),
    ).reset_index()

    # Standardize and build base FIPI (equal weights)
    print("Computing base FIPI using standardized indicators (z-scores)...")

    indicator_cols = [
        "share_extreme_poverty",
        "share_high_crowding",
        "share_high_food_burden",
        "ivd_mean"
    ]

    for col in indicator_cols:
        mean_val = grouped[col].mean()
        std_val = grouped[col].std(ddof=0)
        if std_val == 0 or np.isnan(std_val):
            grouped[col + "_z"] = 0.0
        else:
            grouped[col + "_z"] = (grouped[col] - mean_val) / std_val

    grouped["FIPI"] = grouped[[c + "_z" for c in indicator_cols]].sum(axis=1)

    # Rescale 0–1 for plotting (optional)
    fmin, fmax = grouped["FIPI"].min(), grouped["FIPI"].max()
    if fmax == fmin:
        grouped["FIPI_scaled"] = 0.5
    else:
        grouped["FIPI_scaled"] = (grouped["FIPI"] - fmin) / (fmax - fmin)

    print("\nTop 5 most vulnerable (highest FIPI):")
    print(
        grouped.sort_values("FIPI", ascending=False)[
            ["bairro_norm", "FIPI", "n_families", "n_people_total"]
        ].head(5).to_string(index=False)
    )

    return grouped


# ============================================================
# 5. MISSING / OUTLIERS
# ============================================================

def missing_and_outlier_report(df: pd.DataFrame) -> None:
    print("\n=== Missing Data Report ===")
    missing = df.isna().sum()
    print(missing[missing > 0])
    missing.to_csv(MISSING_OUTPUT)

    print("\n=== Outlier Summary (|z|>3) ===")
    numeric_cols = df.select_dtypes(include=np.number).columns
    zscores = (df[numeric_cols] - df[numeric_cols].mean()) / df[numeric_cols].std(ddof=0)
    outliers = (zscores.abs() > 3).sum().sort_values(ascending=False)
    print(outliers[outliers > 0])
    outliers.to_csv(OUTLIERS_OUTPUT)


# ============================================================
# 6. CORRELATION + PCA
# ============================================================

def run_correlation_analysis(grouped_df: pd.DataFrame) -> pd.DataFrame:
    print("\n=== Correlation Matrix of Neighborhood Indicators ===")
    indicators = grouped_df[[
        "share_extreme_poverty",
        "share_high_crowding",
        "share_high_food_burden",
        "ivd_mean"
    ]]

    corr = indicators.corr()
    print(corr)

    # Usar a mesma paleta divergente do FIPI (coerência visual)
    cmap = plt.colormaps.get_cmap("RdYlBu_r")

    plt.figure(figsize=(6, 5))
    im = plt.imshow(corr, vmin=-1, vmax=1, cmap=cmap)
    cbar = plt.colorbar(im)
    cbar.set_label("Pearson correlation")
    plt.xticks(range(len(indicators.columns)), indicators.columns, rotation=45, ha="right")
    plt.yticks(range(len(indicators.columns)), indicators.columns)
    plt.title("Correlation Matrix of Vulnerability Indicators")
    plt.tight_layout()
    plt.savefig(CORR_FIG_OUTPUT, dpi=300, bbox_inches="tight")
    plt.close()

    return corr


def run_pca_analysis(grouped_df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Run PCA over the four indicators and construct a PCA-based FIPI.
    Returns:
      grouped_df with extra columns for PCA-based indices;
      PCA loadings DataFrame.
    """

    print("\n=== Running PCA Analysis ===")

    indicators = grouped_df[[
        "share_extreme_poverty",
        "share_high_crowding",
        "share_high_food_burden",
        "ivd_mean"
    ]]

    scaler = StandardScaler()
    X = scaler.fit_transform(indicators)

    pca = PCA(n_components=4, random_state=42)
    pca.fit(X)

    print("\nExplained variance ratio (PCA):")
    print(pca.explained_variance_ratio_)

    loadings = pd.DataFrame(
        pca.components_.T,
        columns=[f"PC{i+1}" for i in range(4)],
        index=indicators.columns
    )

    print("\nPCA Loadings:")
    print(loadings)

    # FIPI_PCA: first principal component (scores)
    grouped_df["FIPI_PCA"] = X @ pca.components_[0]

    # Alternative: FIPI_PCA_weights – explicit PC1 weights
    pc1_weights = pca.components_[0]
    grouped_df["FIPI_PCA_weights"] = X @ pc1_weights

    return grouped_df, loadings


# ============================================================
# 7. UNCERTAINTY (STANDARD ERRORS)
# ============================================================

def compute_uncertainty(df: pd.DataFrame, grouped_df: pd.DataFrame) -> pd.DataFrame:
    """
    Compute standard errors for:
      - share_extreme_poverty
      - share_high_crowding
      - share_high_food_burden
      - ivd_mean (sd / sqrt(n))
      - FIPI (via linear propagation assuming independence)
    """

    print("\n=== Computing Standard Errors for Indicator Shares and FIPI ===")

    rows = []
    for bairro in grouped_df["bairro_norm"]:
        sub = df[df["bairro_norm"] == bairro]
        n = len(sub)

        if n == 0:
            rows.append([bairro, np.nan, np.nan, np.nan, np.nan, np.nan])
            continue

        p_ext = sub["is_extreme_poor"].mean()
        p_crowd = sub["is_high_crowding"].mean()
        p_food = sub["is_high_food_burden"].mean()

        se_ext = np.sqrt(p_ext * (1 - p_ext) / n) if (p_ext not in [0, 1]) else 0.0
        se_crowd = np.sqrt(p_crowd * (1 - p_crowd) / n) if (p_crowd not in [0, 1]) else 0.0
        se_food = np.sqrt(p_food * (1 - p_food) / n) if (p_food not in [0, 1]) else 0.0
        se_ivd = sub["ivd_mean"].std(ddof=1) / np.sqrt(n) if n > 1 else np.nan

        # crude SE for FIPI: assuming independence between indicators
        se_fipi = np.sqrt(se_ext**2 + se_crowd**2 + se_food**2 + se_ivd**2)

        rows.append([bairro, se_ext, se_crowd, se_food, se_ivd, se_fipi])

    se_df = pd.DataFrame(rows, columns=[
        "bairro_norm",
        "se_extreme_poverty",
        "se_crowding",
        "se_food_burden",
        "se_ivd_mean",
        "se_FIPI"
    ])

    print(se_df.head())
    return se_df


# ============================================================
# 8. BOLSA FAMÍLIA COVERAGE ANALYSIS
# ============================================================

def run_pbf_coverage_analysis(grouped_df: pd.DataFrame) -> None:
    """
    External validation 1: Bolsa Família coverage by neighborhood.
      - number and share of beneficiary families
      - correlation between FIPI and share_pbf_families
    """
    if "share_pbf_families" not in grouped_df.columns:
        print("\n[WARNING] Column 'share_pbf_families' not found – skipping PBF coverage analysis.")
        return

    print("\n=== Bolsa Família coverage by neighborhood ===")

    df = grouped_df.copy()
    df["share_pbf_families"] = df["share_pbf_families"].fillna(0)
    df["pbf_per_100_families"] = 100 * df["share_pbf_families"]

    summary = df.sort_values("FIPI", ascending=False)[[
        "bairro_norm", "FIPI", "n_families", "n_pbf_families", "pbf_per_100_families"
    ]]

    print(summary.to_string(index=False, float_format=lambda x: f"{x:0.2f}"))

    corr_pearson = df[["FIPI", "share_pbf_families"]].corr().loc["FIPI", "share_pbf_families"]
    corr_spearman = df[["FIPI", "share_pbf_families"]].corr(method="spearman").loc["FIPI", "share_pbf_families"]

    print(f"\nCorrelation FIPI × PBF coverage (Pearson):  {corr_pearson:0.3f}")
    print(f"Correlation FIPI × PBF coverage (Spearman): {corr_spearman:0.3f}")

    df.to_csv(PBF_COVERAGE_OUTPUT, index=False, sep=";")
    print(f"\nPBF coverage table saved to: {PBF_COVERAGE_OUTPUT}")


# ============================================================
# 9. SCHOOL SUPPLY – EXTERNAL VALIDATION 2
# ============================================================

def load_schools_dataset(path: str) -> pd.DataFrame:
    """
    Load the schools dataset and normalize neighborhood names.

    Robust to different column names:
    - Detects the column that contains the neighborhood/locality.
    - If there is an explicit numeric column with the number of schools
      (e.g. 'qtd_escolas'), it uses that column.
    - Otherwise, it assumes one row = one school and just counts rows.
    """
    print("\nLoading schools dataset...")
    if not os.path.exists(path):
        print(f"[WARNING] Schools CSV not found at: {path}")
        return pd.DataFrame(columns=["bairro_norm", "n_schools"])

    # Brazilian Excel usually exports with ';' as separator; adjust if needed.
    try:
        df = pd.read_csv(path, sep=";", encoding="latin1")
    except Exception:
        df = pd.read_csv(path)  # fallback to default separator

    print("Schools CSV columns:", df.columns.tolist())

    # 1) Guess the neighborhood column
    candidates = [
        c for c in df.columns
        if "bair" in c.lower() or "local" in c.lower() or "nome" in c.lower()
    ]
    if not candidates:
        raise ValueError("Could not identify neighborhood column in schools CSV.")
    name_col = candidates[0]
    print("Assuming neighborhood column in schools CSV:", name_col)

    df["bairro_norm"] = df[name_col].apply(normalize_bairro)

    # 2) Try to detect an explicit "number of schools" column
    count_col = None
    for c in df.columns:
        cl = c.lower()
        if ("qtd" in cl or "quant" in cl or "num" in cl) and ("escol" in cl or "school" in cl):
            count_col = c
            break

    if count_col is not None:
        print(f"Using column '{count_col}' as the number of schools per row.")
        # Handle possible decimal comma etc.
        df[count_col] = (
            df[count_col]
            .astype(str)
            .str.replace(".", "", regex=False)   # remove thousand separators if any
            .str.replace(",", ".", regex=False)  # convert decimal comma to dot
        )
        df[count_col] = pd.to_numeric(df[count_col], errors="coerce").fillna(0)
        grouped = (
            df.groupby("bairro_norm")[count_col]
              .sum()
              .reset_index(name="n_schools")
        )
    else:
        print("No explicit school-count column found; assuming one row = one school.")
        grouped = df.groupby("bairro_norm").size().reset_index(name="n_schools")

    grouped["n_schools"] = grouped["n_schools"].round().astype(int)

    print("\nSchools per neighborhood (from schools CSV):")
    print(grouped.to_string(index=False))

    return grouped


def run_school_coverage_analysis(grouped_df: pd.DataFrame) -> None:
    """
    External validation 2: relate FIPI to school supply.

    For each neighborhood:
      - number of schools (from ESCOLAS_GUARAMIRIM.csv)
      - schools per 1,000 CadÚnico families
      - correlation between FIPI and school supply

    This is *not* used to build FIPI; it is only for external validation.
    """
    schools_df = load_schools_dataset(INPUT_SCHOOLS)
    if schools_df.empty:
        print("\n[WARNING] No schools data available – skipping school coverage analysis.")
        return

    df = grouped_df.copy()
    df = df.merge(schools_df, on="bairro_norm", how="left")

    # neighborhoods with no school in the CSV get 0
    df["n_schools"] = df["n_schools"].fillna(0).astype(int)

    # schools per 1,000 CadÚnico families
    df["schools_per_1000_families"] = np.where(
        df["n_families"] > 0,
        1000 * df["n_schools"] / df["n_families"],
        np.nan
    )

    print("\n=== School supply by neighborhood (external validation) ===")
    summary = df.sort_values("FIPI", ascending=False)[[
        "bairro_norm",
        "FIPI",
        "n_families",
        "n_schools",
        "schools_per_1000_families"
    ]]
    print(summary.to_string(index=False, float_format=lambda x: f"{x:0.2f}"))

    # correlations: high FIPI x low school supply?
    corr_pearson = df[["FIPI", "schools_per_1000_families"]].corr().loc["FIPI", "schools_per_1000_families"]
    corr_spearman = df[["FIPI", "schools_per_1000_families"]].corr(method="spearman").loc["FIPI", "schools_per_1000_families"]

    print(f"\nCorrelation FIPI × schools per 1,000 families (Pearson):  {corr_pearson:0.3f}")
    print(f"Correlation FIPI × schools per 1,000 families (Spearman): {corr_spearman:0.3f}")

    df.to_csv(SCHOOLS_COVERAGE_OUTPUT, index=False, sep=";")
    print(f"\nSchool coverage table saved to: {SCHOOLS_COVERAGE_OUTPUT}")

# ============================================================
# 10. FIPI SENSITIVITY ANALYSIS
# ============================================================

def compute_fipi_variants_for_sensitivity(grouped_df: pd.DataFrame) -> pd.DataFrame:
    """
    Construct additional FIPI variants for robustness checks:

    - FIPI: base sum of z-scores (already in grouped_df).
    - FIPI_PCA: PC1 scores (already populated in run_pca_analysis).
    - FIPI_PCA_weights: same as FIPI_PCA but explicit weights.
    - FIPI_IVD2: give double weight to IVD dimension.
    """

    print("\n=== Running FIPI sensitivity analysis ===")

    indicator_z_cols = [
        "share_extreme_poverty_z",
        "share_high_crowding_z",
        "share_high_food_burden_z",
        "ivd_mean_z"
    ]
    if not all(col in grouped_df.columns for col in indicator_z_cols):
        raise ValueError("Z-score columns missing; aggregate_by_bairro must run first.")

    grouped_df["FIPI_IVD2"] = (
        grouped_df["share_extreme_poverty_z"] +
        grouped_df["share_high_crowding_z"] +
        grouped_df["share_high_food_burden_z"] +
        2 * grouped_df["ivd_mean_z"]
    )

    for col in ["FIPI", "FIPI_PCA", "FIPI_PCA_weights", "FIPI_IVD2"]:
        grouped_df[col + "_rank"] = grouped_df[col].rank(method="average", ascending=False)

    ranks = grouped_df[[
        "FIPI_rank",
        "FIPI_PCA_rank",
        "FIPI_PCA_weights_rank",
        "FIPI_IVD2_rank"
    ]]

    spearman_corr = ranks.corr(method="spearman")

    print("\nSpearman rank-correlation between index variants:")
    print(spearman_corr)

    spearman_corr.to_csv(SENSITIVITY_OUTPUT, sep=";")
    print(f"Sensitivity analysis saved to: {SENSITIVITY_OUTPUT}")

    return grouped_df


# ============================================================
# 11. SPATIAL DATA AND LISA
# ============================================================

def load_bairros_shapefile(path: str) -> Tuple[gpd.GeoDataFrame, str]:
    """Load official neighborhood polygons and normalize names."""
    print("\nLoading neighborhood shapefile...")
    gdf = gpd.read_file(path)
    print("Shapefile columns:", gdf.columns.tolist())

    candidates = [c for c in gdf.columns
                  if "bair" in c.lower() or "nome" in c.lower()]
    if not candidates:
        raise ValueError("Could not automatically identify neighborhood name column.")
    name_col = candidates[0]
    print("Using column for neighborhood name:", name_col)

    gdf["bairro_norm"] = gdf[name_col].apply(normalize_bairro)
    return gdf, name_col


def load_municipal_boundary(path: str, crs_target) -> gpd.GeoSeries:
    print("\nLoading municipal boundary shapefile...")
    gdf_muni = gpd.read_file(path)

    if gdf_muni.crs != crs_target:
        gdf_muni = gdf_muni.to_crs(crs_target)

    try:
        boundary = gdf_muni.union_all()
    except AttributeError:
        boundary = gdf_muni.unary_union

    return boundary


def run_spatial_autocorrelation(gdf: gpd.GeoDataFrame):
    """
    Compute global Moran's I and LISA, adding columns to GeoDataFrame:
      - local_moran, lisa_p, lisa_q
      - FIPI_z, lag_FIPI
      - lisa_quadrant (High-High, Low-Low, etc.)
    """

    print("\n=== Moran’s I Spatial Autocorrelation ===")

    gdf = gdf.copy()

    # explicit use_index to silence FutureWarning and keep current behavior
    w = Queen.from_dataframe(gdf, use_index=False)
    w.transform = "r"

    # correct count of disconnected components
    labels = np.array(w.component_labels)
    n_components = len(np.unique(labels))
    if n_components > 1:
        print(f"[WARNING] The weights matrix is not fully connected: "
              f"{n_components} disconnected components.")

    y = gdf["FIPI"].values

    moran = Moran(y, w, permutations=999)

    print("Moran's I:", moran.I)
    print("Expected I:", moran.EI)
    print("p-value (permutation):", moran.p_sim)

    lisa = Moran_Local(y, w, permutations=999)

    gdf["local_moran"] = lisa.Is
    gdf["lisa_p"] = lisa.p_sim
    gdf["lisa_q"] = lisa.q

    gdf["FIPI_z"] = (y - y.mean()) / y.std(ddof=0)
    gdf["lag_FIPI"] = w.sparse.dot(y)

    quad_map = {
        1: "High-High",
        2: "Low-High",
        3: "Low-Low",
        4: "High-Low"
    }
    gdf["lisa_quadrant"] = gdf["lisa_q"].map(quad_map)

    return gdf, moran, lisa


def save_spatial_stats_summary(moran: Moran, gdf_spatial: gpd.GeoDataFrame) -> None:
    """Save a compact CSV summary of spatial statistics."""
    summary = {
        "Moran_I": [moran.I],
        "Moran_EI": [moran.EI],
        "Moran_p_sim": [moran.p_sim],
        "n_areas": [len(gdf_spatial)],
        "n_lisa_sig_0_05": [(gdf_spatial["lisa_p"] < 0.05).sum()],
    }
    df_summary = pd.DataFrame(summary)
    df_summary.to_csv(SPATIAL_STATS_SUMMARY, index=False, sep=";")
    print(f"Spatial stats summary saved to: {SPATIAL_STATS_SUMMARY}")


# ============================================================
# 12. MAPS (FIPI + LISA)
# ============================================================

def generate_map_fipi(
    gdf: gpd.GeoDataFrame,
    muni_boundary,
    name_col: str,
    out_map: str,
    out_table: str
) -> None:
    """Generate FIPI choropleth map and color-coded table, with municipal boundary."""

    cmap = plt.colormaps.get_cmap("RdYlBu_r")
    vmin, vmax = gdf["FIPI"].min(), gdf["FIPI"].max()
    norm = plt.Normalize(vmin=vmin, vmax=vmax)

    # --------------------------
    # Mapa FIPI
    # --------------------------
    fig, ax = plt.subplots(figsize=(7, 7))

    if muni_boundary is not None:
        gpd.GeoSeries([muni_boundary]).boundary.plot(
            ax=ax, edgecolor="black", linewidth=1.2, zorder=1
        )

    gdf.plot(
        column="FIPI",
        cmap=cmap,
        norm=norm,
        ax=ax,
        edgecolor="black",
        linewidth=0.3,
        legend=False,
        zorder=2
    )

    ax.set_axis_off()
    ax.set_title("Guaramirim – FIPI by Neighborhood")

    # colorbar consistente
    sm = plt.cm.ScalarMappable(cmap=cmap, norm=norm)
    sm._A = []
    cbar = fig.colorbar(sm, ax=ax, fraction=0.046, pad=0.04)
    cbar.set_label("FIPI (standardized index)")

    plt.tight_layout()
    plt.savefig(out_map, dpi=300, bbox_inches="tight")
    plt.close(fig)

    # --------------------------
    # Tabela colorida
    # --------------------------
    df_t = gdf[[name_col, "FIPI"]].sort_values("FIPI", ascending=False)
    colors = [cmap(norm(v)) for v in df_t["FIPI"]]

    cell_text = [
        [row[name_col], f"{row['FIPI']:.2f}", ""]
        for _, row in df_t.iterrows()
    ]

    fig_t, ax_t = plt.subplots(figsize=(6, 0.35 * len(df_t) + 1))
    ax_t.axis("off")

    table = ax_t.table(
        cellText=cell_text,
        colLabels=["Neighborhood", "FIPI (standardized)", "Color"],
        loc="center",
        cellLoc="center"
    )
    table.auto_set_font_size(False)
    table.set_fontsize(8)
    table.scale(1, 1.2)

    for i, color in enumerate(colors, start=1):
        table[(i, 2)].set_facecolor(color)

    plt.tight_layout()
    plt.savefig(out_table, dpi=300, bbox_inches="tight")
    plt.close(fig_t)


def generate_lisa_figures(
    gdf: gpd.GeoDataFrame,
    muni_boundary,
    out_scatter: str,
    out_clusters: str,
    out_significant: str
) -> None:
    """Generate Moran scatterplot and LISA maps.

    Colors (fixed across all figures):
      - High-High: strong red
      - Low-Low: strong blue
      - High-Low: orange
      - Low-High: light blue

    Significance map:
      - Red       = p < 0.05
      - Lightgrey = not significant
    """

    quad_colors = {
        "High-High": "#d7191c",  # red
        "Low-Low":   "#2c7bb6",  # blue
        "High-Low":  "#fdae61",  # orange
        "Low-High":  "#abd9e9",  # light blue
    }

    # ==================================================
    # 1) Moran Scatterplot
    # ==================================================
    fig, ax = plt.subplots(figsize=(6, 6))
    ax.scatter(
        gdf["FIPI_z"],
        gdf["lag_FIPI"],
        c=gdf["lisa_quadrant"].map(quad_colors),
        edgecolor="black",
        s=70
    )
    ax.axvline(0, color="black")
    ax.axhline(0, color="black")
    ax.set_xlabel("Standardized FIPI (z-score)")
    ax.set_ylabel("Spatial Lag of FIPI")
    ax.set_title("Moran Scatterplot – FIPI")

    from matplotlib.lines import Line2D
    legend_elements = [
        Line2D([0], [0], marker='o', color='w', label='High–High',
               markerfacecolor=quad_colors["High-High"], markeredgecolor='black', markersize=8),
        Line2D([0], [0], marker='o', color='w', label='Low–Low',
               markerfacecolor=quad_colors["Low-Low"], markeredgecolor='black', markersize=8),
        Line2D([0], [0], marker='o', color='w', label='High–Low',
               markerfacecolor=quad_colors["High-Low"], markeredgecolor='black', markersize=8),
        Line2D([0], [0], marker='o', color='w', label='Low–High',
               markerfacecolor=quad_colors["Low-High"], markeredgecolor='black', markersize=8),
    ]
    ax.legend(handles=legend_elements, loc="upper right", title="LISA quadrant")

    plt.tight_layout()
    plt.savefig(out_scatter, dpi=300, bbox_inches="tight")
    plt.close(fig)

    # ==================================================
    # 2) LISA Quadrant Map
    # ==================================================
    fig, ax = plt.subplots(figsize=(7, 7))

    if muni_boundary is not None:
        gpd.GeoSeries([muni_boundary]).boundary.plot(
            ax=ax, edgecolor="black", linewidth=1.2, zorder=1
        )

    gdf.plot(
        ax=ax,
        edgecolor="black",
        linewidth=0.3,
        zorder=2,
        color=gdf["lisa_quadrant"].map(quad_colors)
    )

    ax.set_axis_off()
    ax.set_title("LISA Quadrant Map – FIPI")

    from matplotlib.patches import Patch
    legend_patches = [
        Patch(facecolor=quad_colors["High-High"], edgecolor='black', label='High–High'),
        Patch(facecolor=quad_colors["Low-Low"],   edgecolor='black', label='Low–Low'),
        Patch(facecolor=quad_colors["High-Low"],  edgecolor='black', label='High–Low'),
        Patch(facecolor=quad_colors["Low-High"],  edgecolor='black', label='Low–High'),
    ]

    # legenda fora do polígono, à direita
    ax.legend(
        handles=legend_patches,
        title="LISA quadrant",
        loc="upper left",
        bbox_to_anchor=(1.02, 1.0),
        borderaxespad=0.0,
        frameon=True
    )

    plt.tight_layout()
    plt.savefig(out_clusters, dpi=300, bbox_inches="tight")
    plt.close(fig)

    # ==================================================
    # 3) LISA Significance Map (p < 0.05)
    # ==================================================
    fig, ax = plt.subplots(figsize=(7, 7))

    if muni_boundary is not None:
        gpd.GeoSeries([muni_boundary]).boundary.plot(
            ax=ax, edgecolor="black", linewidth=1.2, zorder=1
        )

    sig = gdf["lisa_p"] < 0.05
    gdf_assign = gdf.assign(sig=sig)

    sig_colors = {True: "red", False: "lightgrey"}

    gdf_assign.plot(
        ax=ax,
        edgecolor="black",
        linewidth=0.3,
        zorder=2,
        color=gdf_assign["sig"].map(sig_colors)
    )

    ax.set_axis_off()
    ax.set_title("LISA Significance Map – FIPI (p < 0.05)")

    from matplotlib.patches import Patch as Patch2
    sig_legend = [
        Patch2(facecolor="red",       edgecolor='black', label="p < 0.05"),
        Patch2(facecolor="lightgrey", edgecolor='black', label="not significant"),
    ]
    ax.legend(
        handles=sig_legend,
        title="Local significance",
        loc="upper left",
        bbox_to_anchor=(1.02, 1.0),
        borderaxespad=0.0,
        frameon=True
    )

    plt.tight_layout()
    plt.savefig(out_significant, dpi=300, bbox_inches="tight")
    plt.close(fig)


# ============================================================
# 13. MAIN PIPELINE
# ============================================================

def main() -> None:
    print("=== Starting FIPI pipeline (ETH-level, Nov/2025 dataset) ===")

    # 1) Load and prepare data
    df_raw = load_cadunico(INPUT_CAD)
    df_prep = prepare_vulnerability_variables(df_raw)

    # 2) Missing and outlier reports
    missing_and_outlier_report(df_prep)

    # 3) Aggregate by neighborhood and compute base FIPI
    agg_bairros = aggregate_by_bairro(df_prep)
    agg_bairros.to_csv(OUTPUT_AGG, index=False, sep=";")
    print(f"\nAggregated table saved to: {OUTPUT_AGG}")

    # 3a) Bolsa Família coverage (external validation)
    run_pbf_coverage_analysis(agg_bairros)

    # 3b) School supply (external validation)
    run_school_coverage_analysis(agg_bairros)

    # 3c) Families in OUTROS (outside spatial analysis)
    total_families = agg_bairros["n_families"].sum()
    outros_families = agg_bairros.loc[
        agg_bairros["bairro_norm"] == "OUTROS", "n_families"
    ].sum()

    if total_families > 0 and outros_families > 0:
        share_outros = outros_families / total_families
        print(
            f"\nFamilies in OUTROS (non-georeferenced, EXCLUDED from spatial analysis): "
            f"{outros_families} ({share_outros:.2%} of all CadÚnico families)."
        )
    else:
        print("\nNo families classified as OUTROS in this dataset.")

    # 4) Correlation analysis
    run_correlation_analysis(agg_bairros)

    # 5) PCA analysis
    agg_bairros, pca_loadings = run_pca_analysis(agg_bairros)
    agg_bairros.to_csv(AGG_WITH_PCA_OUTPUT, index=False, sep=";")
    print(f"PCA-extended aggregation saved to: {AGG_WITH_PCA_OUTPUT}")

    # 6) Uncertainty / standard errors
    se_df = compute_uncertainty(df_prep, agg_bairros)
    se_df.to_csv(UNCERTAINTY_OUTPUT, index=False, sep=";")
    print(f"Uncertainty measures saved to: {UNCERTAINTY_OUTPUT}")

    # 7) FIPI sensitivity analysis (variants)
    agg_bairros = compute_fipi_variants_for_sensitivity(agg_bairros)

    # 8) Spatial data
    gdf_bairros, name_col = load_bairros_shapefile(BAIRROS_SHP)

    print("\nMerging neighborhood polygons with aggregated FIPI...")
    gdf_merged = gdf_bairros.merge(agg_bairros, on="bairro_norm", how="inner")

    print(f"Neighborhoods in shapefile: {len(gdf_bairros)}")
    print(f"Neighborhoods with FIPI after merge: {len(gdf_merged)}")

    missing = set(agg_bairros["bairro_norm"]) - set(gdf_merged["bairro_norm"])
    if missing:
        print("\nThese neighborhoods have FIPI but no polygon in the shapefile:")
        for b in sorted(list(missing)):
            print("  -", b)
    else:
        print("\nAll FIPI neighborhoods matched polygons.")

    # 9) Municipal boundary
    if os.path.exists(MUNICIPIO_SHP):
        muni_boundary = load_municipal_boundary(MUNICIPIO_SHP, gdf_bairros.crs)
    else:
        try:
            muni_boundary = gdf_bairros.union_all()
        except AttributeError:
            muni_boundary = gdf_bairros.unary_union

    # 10) Spatial autocorrelation (Moran I + LISA)
    gdf_spatial, moran, lisa = run_spatial_autocorrelation(gdf_merged)
    gdf_spatial.to_file(SPATIAL_LISA_OUTPUT, driver="GeoJSON")
    print(f"Spatial dataset with LISA saved to: {SPATIAL_LISA_OUTPUT}")
    save_spatial_stats_summary(moran, gdf_spatial)

    # 11) Maps: FIPI + LISA
    print("\nGenerating FIPI map and table...")
    generate_map_fipi(gdf_spatial, muni_boundary, name_col, MAP_OUTPUT, TABLE_OUTPUT)

    print("Generating LISA figures...")
    generate_lisa_figures(
        gdf_spatial,
        muni_boundary,
        LISA_SCATTER_OUTPUT,
        LISA_CLUSTERS_OUTPUT,
        LISA_SIGNIFICANT_OUTPUT
    )

    print("\n=== Pipeline completed successfully ===")


if __name__ == "__main__":
    main()